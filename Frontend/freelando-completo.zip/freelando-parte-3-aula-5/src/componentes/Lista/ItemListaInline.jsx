import styled from '@emotion/styled'

export const ItemListaInline = styled.li`
    display: inline-block;
`