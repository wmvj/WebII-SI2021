import styled from '@emotion/styled'

export const ListaInline = styled.ul`
    padding: 0;
    margin: 0;
    list-style: none;
`